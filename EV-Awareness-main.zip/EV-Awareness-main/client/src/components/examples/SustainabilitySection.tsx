import { SustainabilitySection } from '../SustainabilitySection'

export default function SustainabilitySectionExample() {
  return <SustainabilitySection />
}
