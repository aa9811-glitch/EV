import { ChargingSystemsSection } from '../ChargingSystemsSection'

export default function ChargingSystemsSectionExample() {
  return <ChargingSystemsSection />
}
