import { ChargingSimulator } from '../ChargingSimulator'

export default function ChargingSimulatorExample() {
  return <ChargingSimulator />
}
